var indexSectionsWithContent =
{
  0: "acdgikmpstv",
  1: "a",
  2: "gmpt",
  3: "cdimps",
  4: "kv",
  5: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

