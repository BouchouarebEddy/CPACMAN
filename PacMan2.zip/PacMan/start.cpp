#include <iostream>
#include <istream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include "../PacMan/gameinit.h"

using namespace std;


void Displaytxt (const string & kfichier){
    ifstream text (kfichier);
    if (text.is_open() ==true){
        string line;
        while(getline(text,line)){
            cout << line <<endl;
        }
     }
    else {
        cout <<"DISPLAY ERROR"<<endl;
    }
}


int ChooseColor(){
//    int choiceColors;
//    cout << "Select your color's skin:"<<endl<<" [1] Green, [2] Yellow, [3] Red"<<endl;
//    cin >> choiceColors;

//    if (choiceColors == 1){
//        return 1;
//        cout <<"You choose the Green's skin ";
//    }
//    if (choiceColors ==2){
//        return 2;
//    }
//    if (choiceColors ==3){
//        return 3;
//    }
////    else {
////           cout <<"Select your color's skin please:"<<endl;
////           cin >> choiceColors;
////    }
}



void MenuUser() {

        string  pseudo;
        cout <<"Choisissez votre pseudo"<<endl;
        cin >> pseudo;
        string const menu("../PacMan/Nos_fichiers/menu.txt");
        Displaytxt(menu);
        cout <<"Your choice: "<<endl;
        int choice;
        cin >> choice;
        if (choice == 1){
            initGame();
        }
        if (choice == 2){
            ChooseColor();

        }
        if (choice == 3){
            exit (0);
        }
}



