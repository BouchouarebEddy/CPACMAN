#ifndef MAPMANAGEMENT_H
#define MAPMANAGEMENT_H
#include <../PacMan/Correc_Prof/type.h>
#include <string>


void initMap(CMat & map);
void displayMap(const CMat & map);


#endif // MAPMANAGEMENT_H
