#include <iostream>
#include "../PacMan/Correc_Prof/type.h"
#include <fstream>
#include "../PacMan/Correc_Prof/params.h"


using namespace std;

void initMap(CMat & map) {
    for (size_t row = 0; row < 10; ++row) {
        CVLine line = {' '};
        for (size_t col = 0; col < 10; ++col) {
            line.push_back(' ');
        }

        map.push_back(line);
    }

}



void displayMap(const CMat & map) {
    for (size_t row = 0; row < map.size(); ++row) {
        for (size_t col = 0; col < map[row].size(); ++col) {
            cout << map[row][col];
        }
        cout << endl;
    }
}
