#include <iostream>
#include "enemies.h"
#include "player.h"
#include "mapManagement.h"
#include "score.h"


using namespace std;


// void moveEnemy(CMat & map, const CPosition & player, CPosition & enemy, bool state);

void checkVictory(const CPosition & player, const vector<CPosition> & listENemy, const bool & state, bool & victory, const vector<CPosition> & listPoints);
void initGame() {
    CMat map;
    CPosition player(10,1);

    CPosition enemy2(1, 1);
    CPosition enemy(1,14);

    vector<CPosition> listEnemy = {enemy, enemy2};
    vector<CPosition> listPoints = {};

    map = initMap(listPoints);

    for (CPosition en : listEnemy) {
        initEnemy(map, en);
    }

    initPlayer(map, player);


    bool isVictory = false;

    while (!isVictory) {
        displayMap(map);

        while(!movePlayer(map, player, listPoints)) {
            displayMap(map);
            cout << endl << "Impossible de se diriger dans cette direction, veuillez-reessayer " << endl;
        }

        for (unsigned i = 0; i < listEnemy.size(); ++i) {
             moveEnemy(map, player, listEnemy[i], true, listPoints);
        }


        checkVictory(player, listEnemy, true, isVictory, listPoints);
    }
    score(map, player, enemy);
}


void checkVictory(const CPosition & player, const vector<CPosition> & listENemy, const bool & state, bool & victory, const vector<CPosition> & listPoints) {
    // Plus de points
    if (listPoints.size() == 0) {
        victory = true;
        cout << "Le joueur a gagné" << endl;
    }

    for (CPosition enemy : listENemy) {
        if (player.first == enemy.first && player.second == enemy.second) {
            if (state) {
                victory = true;
                cout << "Les enemies ont  gagnés" << endl;
            } else {
                victory = true;
                cout << "Le joueur a gagné" << endl;
            }
        }
    }
}
