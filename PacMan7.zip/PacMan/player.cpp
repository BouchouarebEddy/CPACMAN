
#include <iostream>
#include <termios.h>
#include <unistd.h>
#include <algorithm>

#include "mapManagement.h"
#include "Correc_Prof/type.h"
#include "start.h"
#include "mapManagement.h"


using namespace std;

int score (0);
int bille (2);
int fruit (10);



void set_input_mode (void)
{
    struct termios tattr;

    /* Make sure stdin is a terminal. */
    if (!isatty (STDIN_FILENO))
    {
        fprintf (stderr, "Not a terminal.\n");
        exit (EXIT_FAILURE);
    }

    /* Set the funny terminal modes. */
    tcgetattr (STDIN_FILENO, &tattr);
    tattr.c_lflag &= ~(ICANON|ECHO); /* Clear ICANON and ECHO. */
    tcsetattr (STDIN_FILENO, TCSAFLUSH, &tattr);
}


void initPlayer(CMat & map, const CPosition & player) {

    map[player.first][player.second] = 'O';
}


void initfruit(CMat & map, const CPosition & fruit) {


    map[fruit.first][fruit.second] = '*';
}


bool movePlayer(CMat & map, CPosition & player, vector<CPosition> & listPoints) {

    cout << "Enter a movement : "<<endl;
    set_input_mode();
    char choice;
    cin >> choice;

    choice = toupper(choice);
    ClearScreen();

    switch (choice)
    {
    case 'Z' :
        if (player.first == 0) {
            if (map[map.size()-1][player.second] == '#') {
                return false;
            }
            player.first = map.size() - 1;
        } else {
            if (map[player.first -1][player.second] == '#') {
                return false;
            }
            map[player.first][player.second] = ' ';
            --player.first;
        }
        break;
    case 'Q':
        if (player.second == 0) {
            if (map[player.first][map[player.first].size()-1] == '#') {
                return false;
            }
            map[player.first][player.second] = ' ';
            player.second = map[player.first].size()-1;
        } else {
            if (map[player.first][player.second -1] == '#') {
                return false;
            }
            map[player.first][player.second] = ' ';
            --player.second;
        }

        break;
    case 'D':
        if (player.second == map[player.first].size()-1) {
            if (map[player.first][0] == '#') {
                return false;
            }
            map[player.first][player.second] = ' ';
            player.second = 0;
        } else {
            if (map[player.first][player.second+1] == '#') {
                return false;
            }
            map[player.first][player.second] = ' ';
            ++player.second;
        }
        break;
    case 'S' :
        if (player.first == map.size()-1) {
            if (map[0][player.second] == '#') {
                return false;
            }
            map[player.first][player.second] = ' ';
            player.first = map.size() - 1;
        } else {
            if (map[player.first+1][player.second] == '#') {
                return false;
            }
            map[player.first][player.second] = ' ';
            ++player.first;
        }
        break;
    default:
        return false;
    }

    // On arrive sur une case '.'
    if (find(listPoints.begin(), listPoints.end(), player) != listPoints.end()) {
        // Incrémenter les scores
        score += 10;

        // supprimer le .
        listPoints.erase(find(listPoints.begin(), listPoints.end(), player));
    }



    map[player.first][player.second] = 'O';
    return true;
}
