#ifndef SCORE_H
#define SCORE_H
#include "Correc_Prof/type.h"
#include "start.h"
#include "mapManagement.h"
#include "Correc_Prof/gridmanagement.h"
#include "player.h"
int score(CMat & map, const CPosition & player, const CPosition & enemy);
#endif // SCORE_H
