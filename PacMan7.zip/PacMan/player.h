#ifndef PLAYER_H
#define PLAYER_H
#include "Correc_Prof/type.h"
#include <termios.h>
#include <unistd.h>

bool movePlayer(CMat & map, CPosition & player, std::vector<CPosition> & listPoints);
void initPlayer(CMat & map, const CPosition & player);
void set_input_mode (void);

#endif // PLAYER_H
