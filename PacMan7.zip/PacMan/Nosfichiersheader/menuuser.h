#ifndef MENUUSER_H
#define MENUUSER_H
unsigned MenuUser();
#endif // MENUUSER_H
