#include <iostream>
#include "../PacMan/Correc_Prof/type.h"
#include <algorithm>    // std::find

using namespace std;



void initEnemy(CMat & map, const CPosition & enemy) {
    map[enemy.first][enemy.second] = 'M';
}


void moveEnemy(CMat & map, const CPosition & player, CPosition & enemy, bool state, const vector<CPosition> & listPoints) {
    if (find(listPoints.begin(), listPoints.end(), enemy) != listPoints.end()) {
        map[enemy.first][enemy.second] = '.';
    } else {
        map[enemy.first][enemy.second] = ' ';
    }
    if (state) {
        if (player.first == enemy.first) {
            // gauche
            if (player.second < enemy.second) {
                if (map[enemy.first][enemy.second-1] != '#' && map[enemy.first][enemy.second-1] != 'M') {

                    --enemy.second;
                }

            } else {
                if (map[enemy.first][enemy.second+1] != '#' && map[enemy.first][enemy.second+1] != 'M') {
                    ++enemy.second;
                }
                // droite
            }
        } else if (player.second == enemy.second) {
            if (player.first < enemy.first) {
                // haut
                if (map[enemy.first-1][enemy.second] != '#' && map[enemy.first-1][enemy.second] != 'M') {
                    --enemy.first;
                }


            } else {
                // bas
                if (map[enemy.first+1][enemy.second] != '#' && map[enemy.first+1][enemy.second] != 'M') {
                    ++enemy.first;
                }

            }
        } else {
            if ((player.first - enemy.first) < (player.second - enemy.second)) {
                if (player.first < enemy.first) {
                    if (map[enemy.first-1][enemy.second] != '#' && map[enemy.first-1][enemy.second] != 'M') {
                        --enemy.first;
                    }
                } else {
                    if (map[enemy.first+1][enemy.second] != '#' && map[enemy.first+1][enemy.second] != 'M') {
                        ++enemy.first;
                    }
                }
            } else {
                if (player.second < enemy.second) {
                    if (map[enemy.first][enemy.second-1] != '#' && map[enemy.first][enemy.second-1] != 'M') {
                        --enemy.second;
                    }
                } else {
                    if (map[enemy.first][enemy.second+1] != '#' && map[enemy.first][enemy.second+1] != 'M') {
                        ++enemy.second;
                    }
                }
            }
        }
    }



    map[enemy.first][enemy.second] = 'M';
}
