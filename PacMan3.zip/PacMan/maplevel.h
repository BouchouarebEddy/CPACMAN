#ifndef MAPLEVEL_H
#define MAPLEVEL_H
CMat initMat(unsigned level);
#endif // MAPLEVEL_H
