
#include <iostream>
#include <../PacMan/Correc_Prof/type.h>
#include <../PacMan/start.h>
#include <termios.h>
#include <unistd.h>


using namespace std;



void set_input_mode (void)
{
struct termios tattr;

/* Make sure stdin is a terminal. */
if (!isatty (STDIN_FILENO))
{
fprintf (stderr, "Not a terminal.\n");
exit (EXIT_FAILURE);
}

/* Set the funny terminal modes. */
tcgetattr (STDIN_FILENO, &tattr);
tattr.c_lflag &= ~(ICANON|ECHO); /* Clear ICANON and ECHO. */
tcsetattr (STDIN_FILENO, TCSAFLUSH, &tattr);
}


void initPlayer(CMat & map, const CPosition & player) {


    map[player.first][player.second] = 'O';
}


void movePlayer(CMat & map, CPosition & player) {
    cout << "Entrez un déplacement : ";
    set_input_mode();
    char choice;
    cin >> choice;


    // VERIFICATION CHAR DE MOUVEMENT

    choice = toupper(choice);

    map[player.first][player.second] = ' ';

    switch (choice)
        {
        case 'Z':
            if (player.first == 0) {
                player.first = map.size()-1;
            }else {
                --player.first;
            }

            break;
        case 'Q':
            if (player.second == 0) {
                player.second = map[player.first].size()-1;
            } else {
                --player.second;
            }

            break;
        case 'D':
            if (player.second == map[player.first].size()-1) {
                player.second = 0;
            } else {
                ++player.second;
            }
            break;
        case 'S':
            if (player.first == map.size()-1) {
                player.first = 0;
            }else {
                ++player.first;
            }
            break;
        }

        map[player.first][player.second] = 'O';

}
