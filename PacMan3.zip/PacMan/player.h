#ifndef PLAYER_H
#define PLAYER_H
#include "../PacMan/Correc_Prof/type.h"
#include <termios.h>
#include <unistd.h>

void initPlayer(CMat & map, const CPosition & player);
void movePlayer(CMat & map, CPosition & player);
void set_input_mode (void);

#endif // PLAYER_H
