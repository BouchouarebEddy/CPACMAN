#include <iostream>
#include "../PacMan/Correc_Prof/type.h"
#include "enemies.h"
#include "player.h"
#include "mapManagement.h"
#include "../PacMan/score.h"


using namespace std;


// void moveEnemy(CMat & map, const CPosition & player, CPosition & enemy, bool state);

void checkVictory(const CPosition & player, const CPosition & enemy, const bool & state, bool & victory);
void initGame() {
    CMat map;
    CPosition player(10,1);
    CPosition enemy(1,14);

    map = initMap();
    initEnemy(map, enemy);
    initPlayer(map, player);

    displayMap(map);


    bool isVictory = false;

    while (!isVictory) {
        movePlayer(map, player);
        moveEnemy(map, player, enemy, true);

        displayMap(map);

        checkVictory(player, enemy, true, isVictory);
    }
    score(map, player, enemy);
}


void checkVictory(const CPosition & player, const CPosition & enemy, const bool & state, bool & victory) {
    if (player.first == enemy.first && player.second == enemy.second) {
        if (state) {
            victory = true;
            cout << "Les enemies ont  gagnés" << endl;
        } else {
            victory = true;
            cout << "Le joueur a gagné" << endl;
        }
    }

}
