#ifndef START_H
#define START_H
#include <string>
void MenuUser();
void Displaytxt (const std::string & kfichier);
void ChooseColor();

#endif // START_H
