#ifndef SCORE_H
#define SCORE_H
#include "../PacMan/Correc_Prof/type.h"
#include "../PacMan/start.h"
#include "mapManagement.h"
#include "Correc_Prof/gridmanagement.h"
#include "player.h"
int score(CMat & map, const CPosition & player, const CPosition & enemy);
#endif // SCORE_H
