#include <iostream>
  #include <istream>
  #include <fstream>
  #include <stdlib.h>
  #include <string>
  #include "../PacMan/gameinit.h"

  using namespace std;


  const string KVert ("32");
  const string KJaune ("33");
  const string KCyan ("36");
  const string KReset ("0");

  void Couleur (const string & coul)
  {
      cout << "\033[" << coul <<"m";
  }


  void Displaytxt (const string & kfichier){
      ifstream text (kfichier);
      if (text.is_open() ==true){
          string line;
          while(getline(text,line)){
              cout << line <<endl;
          }
      }
      else {
          cout <<"DISPLAY ERROR"<<endl;
      }
  }

  int ChooseColor(){
      int choiceColors = -1;
      while ((choiceColors != 1) || (choiceColors != 2) || (choiceColors != 3 ) || (choiceColors != 4)) {

          cout << "Select your color :"<<endl<<" [1] Green, [2] Yellow, [3] Cyan, [4] Reset Color"<<endl;
          cin >> choiceColors;
          if (choiceColors == 1){
              Couleur(KVert);
              cout <<"You choose the Green color " <<endl;
              return choiceColors;
          }
          else if (choiceColors ==2){
              Couleur(KJaune);
              cout <<"You choose the Yellow color " <<endl;
              return choiceColors;
          }
          else if (choiceColors ==3){
              Couleur(KCyan);
              cout <<"You choose the Cyan color " <<endl;
              return choiceColors;
          }
          else if (choiceColors ==4){
              Couleur(KReset);
              cout <<"You choose the Main color " <<endl;
              return choiceColors;
          }
      }
  }


  void MenuUser() {
      int Choicemenu = -1;

      string const menu("../PacMan/Nos_fichiers/menu.txt");
      Displaytxt(menu);
      while ((Choicemenu != 1) || (Choicemenu != 2) || (Choicemenu != 3)){
          cout <<"Choice 1, 2 or 3: "<<endl;

          cin >> Choicemenu;
          if (Choicemenu == 1){
              string  pseudo;
              cout <<"Choisissez votre pseudo :"<<endl;
              cin >> pseudo;
              initGame();
              Choicemenu = -1;
              string test = "";
              getline(cin, test);
          }
          else if (Choicemenu == 2){

              ChooseColor();
          }
          else if (Choicemenu == 3){

              exit (0);

         }
//          else {
//              Choicemenu = -1;  Bug a regler
//              string test = "";
//              getline(cin, test);
//          }
      }

  }
