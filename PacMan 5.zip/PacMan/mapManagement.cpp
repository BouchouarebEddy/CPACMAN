#include <iostream>
#include "../PacMan/Correc_Prof/type.h"
#include <fstream>
#include "../PacMan/Correc_Prof/params.h"


using namespace std;

vector<vector<char>> initMap() {
    ifstream ifs("../PacMan/Nos_fichiers/map.txt");
    string ligneLue;

    vector<vector<char>> map = {};
    vector<char> ligne = {};

    while (getline(ifs, ligneLue)) {
        for (unsigned i = 0; i < ligneLue.size(); ++i) {
            ligne.push_back(ligneLue[i]);
        }
        map.push_back(ligne);
        ligne = {};
    }

    return map;
}




void displayMap(const CMat & map) {
    for (size_t row = 0; row < map.size(); ++row) {
        for (size_t col = 0; col < map[row].size(); ++col) {
            cout << map[row][col];
        }
        cout << endl;
    }
}
