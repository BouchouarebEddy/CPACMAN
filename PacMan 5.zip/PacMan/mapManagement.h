#ifndef MAPMANAGEMENT_H
#define MAPMANAGEMENT_H
#include <vector>
#include <../PacMan/Correc_Prof/type.h>
#include <string>


std::vector<std::vector<char>> initMap();
void displayMap(const CMat & map);


#endif // MAPMANAGEMENT_H
