#ifndef MAPMANAGEMENT_H
#define MAPMANAGEMENT_H
#include <vector>
#include <string>
#include "Correc_Prof/type.h"


std::vector<std::vector<char>> initMap(std::vector<CPosition> & listPoints);
void displayMap(const CMat & map);
void ClearScreen ();

#endif // MAPMANAGEMENT_H
