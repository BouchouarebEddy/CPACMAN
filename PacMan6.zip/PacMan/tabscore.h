#ifndef TABSCORE_H
#define TABSCORE_H

#endif // TABSCORE_H
