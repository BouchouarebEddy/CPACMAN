#include <iostream>
#include "Correc_Prof/type.h"
#include "start.h"
#include "mapManagement.h"
#include "Correc_Prof/gridmanagement.h"
#include "player.h"
#include "enemies.h"
#include "gameinit.h"

using namespace std;


int score(CMat & map, const CPosition & player, const CPosition & enemy){

    int score (0);
    int bille (2);
    int fruit (10);

    while (player.first != enemy.first && player.second != enemy.second){
        if (map[player.first-1][player.second] == '*') {
          cout <<"10"<<endl;
            return score;
        }
        else if (map[player.first-1][player.second] == '.') {
            cout <<"2"<<endl;
        }

        else if (player.first == enemy.first && player.second == enemy.second){
            break;
        }

    }

}

