#ifndef GAMEINIT_H
#define GAMEINIT_H
#include "./Correc_Prof/type.h"
void initGame();
void checkVictory(const CPosition & player, const std::vector<CPosition> & listENemy, const bool & state, bool & victory, const std::vector<CPosition> & listPoints);
#endif // GAMEINIT_H
