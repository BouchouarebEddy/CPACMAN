#include <iostream>
#include <fstream>
#include "Correc_Prof/type.h"

using namespace std;

vector<vector<char>> initMap(vector<CPosition> & listPoints) {
    ifstream ifs("../PacMan/Nos_fichiers/map.txt");
    string ligneLue;

    vector<vector<char>> map = {};
    vector<char> ligne = {};

    unsigned line = 0;
    while (getline(ifs, ligneLue)) {
        for (unsigned i = 0; i < ligneLue.size(); ++i) {
            if (ligneLue[i] == '.') {
                listPoints.push_back({line, i});
            }
            ligne.push_back(ligneLue[i]);
        }
        ++line;
        map.push_back(ligne);
        ligne = {};
    }

    return map;
}

void ClearScreen ()
{
    cout << "\033[H\033[2J";
}

void displayMap(const CMat & map) {
    for (size_t row = 0; row < map.size(); ++row) {
        for (size_t col = 0; col < map[row].size(); ++col) {
            cout << map[row][col];
        }
        cout << endl;
    }
}
