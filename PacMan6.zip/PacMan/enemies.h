#ifndef ENEMIES_H
#define ENEMIES_H
#include "Correc_Prof/type.h"


void initEnemy(CMat & map, const CPosition & enemy);
void moveEnemy(CMat & map, const CPosition & player, CPosition & enemy, bool state, const std::vector<CPosition> & listPoints);

#endif // ENEMIES_H
