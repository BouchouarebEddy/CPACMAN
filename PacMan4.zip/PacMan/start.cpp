#include <iostream>
   #include <istream>
   #include <fstream>
   #include <stdlib.h>
   #include <string>
   #include "../PacMan/gameinit.h"

   using namespace std;


   void Displaytxt (const string & kfichier){
       ifstream text (kfichier);
       if (text.is_open() ==true){
           string line;
           while(getline(text,line)){
               cout << line <<endl;
           }
       }
       else {
           cout <<"DISPLAY ERROR"<<endl;
       }
   }

   int ChooseColor(){
       int choiceColors = -1;
       while ((choiceColors != 7) || (choiceColors != 8) || (choiceColors != 9 )) {

           cout << "Select your color's skin:"<<endl<<" [7] Green, [8] Yellow, [9] Red"<<endl;
           cin >> choiceColors;
           if (choiceColors == 7){

               cout <<"You choose the Green's skin " <<endl;
               return choiceColors;
           }
           else if (choiceColors ==8){

               cout <<"You choose the Yellow's skin " <<endl;
               return choiceColors;
           }
           else if (choiceColors ==9){

               cout <<"You choose the Red's skin " <<endl;
               return choiceColors;
           }
       }
   }

   void MenuUser() {
       int Choicemenu = -1;
       string  pseudo;
       cout <<"Choisissez votre pseudo"<<endl;
       cin >> pseudo;
       string const menu("../PacMan/Nos_fichiers/menu.txt");
       Displaytxt(menu);
       while ((Choicemenu != 1) || (Choicemenu != 2) || (Choicemenu != 3)){
           cout <<"Choice 1, 2 or 3: "<<endl;
           cin >> Choicemenu;
           if (Choicemenu == 1){

               initGame();
               Choicemenu = -1;
               string test = "";
               getline(cin, test);
           }
           else if (Choicemenu == 2){

               ChooseColor();
           }
           else if (Choicemenu == 3){

               exit (0);
           }
       }
   }
