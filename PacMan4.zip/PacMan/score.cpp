#include <iostream>
#include "../PacMan/Correc_Prof/type.h"
#include "../PacMan/start.h"
#include "mapManagement.h"
#include "Correc_Prof/gridmanagement.h"
#include "player.h"

using namespace std;


int score(CMat & map, const CPosition & player){

    int score (0);
    int bille (2);
    int fruit (10);

    if (map[player.first-1][player.second] == '*') {
        score = score + fruit;
    }
    if (map[player.first-1][player.second] == '.') {
        score = score + bille;
    }



}
