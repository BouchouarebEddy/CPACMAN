//#ifndef COLOR_H
//#define COLOR_H

//void Color (const string & coul);
//#endif // COLOR_H
