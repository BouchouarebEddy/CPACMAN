#ifndef SCORE_H
#define SCORE_H
#include C
int score(CMat & map, const CPosition & player)
#endif // SCORE_H
