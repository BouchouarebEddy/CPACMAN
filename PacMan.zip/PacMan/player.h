#ifndef PLAYER_H
#define PLAYER_H
#include "../PacMan/Correc_Prof/type.h"

void initPlayer(CMat & map, const CPosition & player);
void movePlayer(CMat & map, CPosition & player);

#endif // PLAYER_H
