#ifndef MENUUSER_H
#define MENUUSER_H
#include <string>

int MenuUser();
void Displaytxt(const std::string & kfichier);

#endif // MENUUSER_H
