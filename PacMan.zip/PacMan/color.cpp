//#include <iostream>
//#include <string>



//using namespace std;

//const string KReset   ("0");
//const string KNoir    ("30");
//const string KRouge   ("31");
//const string KVert    ("32");
//const string KJaune   ("33");
//const string KBleu    ("34");
//const string KMAgenta ("35");
//const string KCyan    ("36");

//void Color (const string & coul)
//{
//    cout << "\033[" << coul <<"m";
//}
